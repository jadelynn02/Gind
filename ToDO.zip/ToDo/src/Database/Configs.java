package Database;

public class Configs {
	
	protected String dbHost = "localhost";
	
	protected String dbPort = "3306";
	
	protected String dbUser = "root";
	
	protected String dbPass = "dichone7";
	
	protected String dbName = "todo";
}
